
<html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
		<meta name="keywords" content="Fashion Sponge,Fashion,Sponge,fashionsponge.com" />
		<meta name="description" content="Fashion Sponge,Fashion,Sponge,fashionsponge.com" />
	</head>
	<title>
		Welcome to Fashion Sponge.
	</title>
	
	<style>
		a img{
			border:0px;
		}
		a{text-decoration:none;border:0px;text-decoration:0;}
		#top_t td{
			padding:5px;
		}
		#signup{
			background:url("images 1/sign-back.png") repeat-x;
			width:636px;
			margin:0 auto;
			-moz-border-radius: 10px;
			-webkit-border-radius: 10px; 
			border-radius: 10px; 
			-moz-box-shadow: 0px 0px 20px #000; 
			-webkit-box-shadow: 0px 0px 20px #000; 
			box-shadow: 0px 0px 20px #000; 
			behavior: url(ie-css3.htc);
		}
		#gradient{
			width:636px;height:229px;
			margin:0 auto;
			/* fallback */
			background-color: #1a82f7;
			background: url(images 1/linear_bg_2.png);
			background-repeat: repeat-x;
			  
			/* Safari 4-5, Chrome 1-9 */
			background: -webkit-gradient(linear, 0% 0%, 0% 100%, from(#1a82f7), to(#2F2727));
			 
			/* Safari 5.1, Chrome 10+ */
			background: -webkit-linear-gradient(top, #2F2727, #1a82f7);
			  
			/* Firefox 3.6+ */
			background: -moz-linear-gradient(top, #2F2727, #1a82f7);
			  
			/* IE 10 */
			background: -ms-linear-gradient(top, #2F2727, #1a82f7);
			  
			  /* Opera 11.10+ */
			  background: -o-linear-gradient(top, #2F2727, #1a82f7);
		}
		
		@font-face {
			font-family: misoBold;
			src: url('fonts/misobold.eot');
			src: local(misoBold), url('fonts/miso-bold.otf') format('opentype');
			src: url('fonts/miso-bold.otf');
		}
		@font-face {
			font-family: misolight;
			src: url('fonts/misolight.eot');
			src: local(misolight), url('fonts/miso-light.otf') format('opentype');
			src: url('fonts/miso-light.otf');
		}
		@font-face {
			font-family: miso;
			src: url('fonts/misoregular.eot');
			src: local(miso), url('fonts/miso-regular.otf') format('opentype');
			src: url('fonts/miso-regular.otf');
		}
		@font-face {
			font-family: raleway_thin;
			src: url('fonts/raleway_thinwebfont.eot');
			src: local(raleway_thin), url('fonts/raleway_thin-webfont.ttf') format('opentype');
			src: url('fonts/raleway_thin-webfont.ttf');
		}
		@font-face {
			font-family: helvetica;
			src: url('fonts/Helvetica.eot');
			src: local(helvetica), url('fonts/Helvetica.otf') format('opentype');
			src: url('fonts/Helvetica.otf');
		}
		@font-face {
			font-family: helveticaBold;
			src: url('fonts/HelveticaBold.eot');
			src: local(helveticaBold), url('fonts/Helvetica-Bold.otf') format('opentype');
			src: url('fonts/Helvetica-Bold.otf');
		}
		
		@font-face {
			font-family: helveticaNarrow;
			src: url('fonts/HelveticaCENarrow.eot');
			src: local(helveticaNarrow), url('fonts/HelveticaCE-Narrow.otf') format('opentype');
			src: url('fonts/HelveticaCE-Narrow.otf');
		}
	</style>
			<?php
				$b=$_SERVER['HTTP_USER_AGENT'];
				if($b=="Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; InfoPath.2; .NET CLR 1.1.4322; .NET4.0C; .NET4.0E; .NET CLR 2.0.50727; handyCafeCln/3.3.21)")
					$b="ie";
				else
					$b="ch";
			?>	
			
<body style="background:black url('images 1/back.jpg') center top no-repeat;color:white;"  >	
<center>
	<div style="width:1024px;margin:0 auto;">
		<table width=100% id="top_t" >
			<td width=90% align=center><a href="http://www.fashionsponge.com/"><img src="images 1/logo.png" style="position:relative;left:100px" /></a> </td>
			<td> <a href="http://www.facebook.com/fashionsponge" target="_blank" title="facebook.com" ><img src="images 1/f.png" /></a> </td>
			<td> <a href="http://www.twitter.com/fashionsponge" target="_blank" title="twitter.com" ><img src="images 1/b.png" /></a> </td>
			<td> <a href="http://www.fashionsponge.tumblr.com" target="_blank" title="thumbler.com"  ><img src="images 1/t.png" /></a> </td>
			<td> <a href="http://www.pinterest.com/fashionsponge" target="_blank" title="pinterest.com"  ><img src="images 1/p.png" /></a> </td>
			<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
		</table>
		<br><br>
		<center>
			<table style="width:900px;height:255px;border-collapse:collapse;" >
				<td width=49.5% style="padding:2px 5px 15px 70px;background:url('images 1/arrow-left.png') left center no-repeat;" > 
					<?php
						if($b=="ch")
							echo '<b style="font:30px misoLight;">SOMETHING COOL IS COMING<br>TO FASHION LOVERS!</b>';
						else
							echo '<b style="font:20px helvetica;">SOMETHING COOL IS COMING<br>TO FASHION LOVERS!</b>';
					?>
					<div style="padding:5px"></div>
					<b style="font-family:misoBold;font-size:20px">share, discover, learn</b>
					<div style="padding:5px"></div>
					<b style="font-family:helvetica;font-size:12px">
					Join a community of tastemakers and creators. FashionSponge is an environment where your style inspires,
					your voice is heard, and your participation is rewarded.
					</b>
					<div style="padding:7px"></div>
					<img src="images 1/steps.png" />
				</td>
				<td width=1% style="background:url('images 1/div2.png') center no-repeat;" ></td>
				<td width=49.5% style="padding:2px 40px 2px 15px; background:url('images 1/arrow-right.png') right center no-repeat;" >
					<table width=100% style="border-collapse:collapse;" >
						<td style="padding:15px">
							<img src="images 1/wms.png" />
						</td>
						<td style="padding:10px" >
							<b style="font-family:misoBold;font-size:20px">the world's most stylish</b>
							<div style="padding:5px"></div>
							<b style="font-family:helvetica;font-size:12px">
								Before our site launch, we will be hosting styling competition that's open to the world.
								The first place prize is $2000 cash and additional prizes.
								<div style="padding:5px"></div>
								<a href="http://fashionsponge.com/twms/contest.php" style="color:white;font-family:helveticaBold;font-size:12px;padding:0 20px 0 0;background:url('images 1/arr-right-small.png') right center no-repeat">ABOUT THE COMPETITION</a>
							</b>
						</td>
					</table>
				</td>
			</table>
		</center>

		<br>
		<div style=\"padding:4px;\"></div>
		<div id="signup" >
			<div style="padding:10px">
				<?php
							if($b=="ch")
								echo "
									<table width=100% border=0>
									<td width=49.5%  style=\"\" >
										<b style=\"font-family:miso;font-size:29px;color:#888;text-shadow: inset -1px 1 2px #000000;\">
										sign up for the private beta</b>
										<div style=\"padding:4px;\"></div>
										<b style=\"font-family:helvetica;font-size:12px;color:#797979;\">
											Enter your email address to receive updates from fashionsponge and an early invite.
										</b>
										<div style=\"padding:4px;\"></div>
										<form method=post>
											<table style=\"border:1px solid #aaa;background:url('images 1/email-back.png') top left repeat-x \" width=100% >
												<td valign=center width=*% ><input name=\"tEmail\" value=\"EMAIL\" style=\"width:100%; padding:5px;font:bold 12px arial;color:#797979;background:transparent;border:0;\" onclick=\"if(this.value=='EMAIL'){this.value=''}\" onblur=\"if(this.value==''){this.value='EMAIL'}\" /></td>
												<td align=right  valign=top width=75 ><input name=\"bSubmit\" type=submit value='SUBMIT' 
													style=\"background:#b80c0c;color:white;width:100%;height:30px;border:0;cursor:pointer;font:18px miso;padding:5px;\"  /></td>
											</table>
										</form>
									</td>
										<td valign=top  ><img src=\"images 1/div.png\" /></td>
										<td width=49.5% valign=top style=\"padding:20px 10px 20px 10px;\" >
											<b style=\"font-family:miso;font-size:29px;color:#888;text-shadow: inset -1px 1 2px #000000;\">already have an invite?</b>
											<div style=\"padding:4px;\"></div>
											<center><a href="'/fs/signup.php'><img src='/images 1/signup-button.png'></a>
													* Signups are currently restricted to invite-only until the beta period is over.
												</b>
											</center>
										</td>
									</table>
								";
							else
								echo "
									<table width=100% border=0>
										<td width=49.5% valign=top  style=\"padding:5px;\" >
											<b style=\"font-family:helvetica;font-size:20px;color:#888;text-shadow: inset -1px 1 2px #000000;\">
											sign up for the private beta</b>
											<div style=\"padding:4px;\"></div>
											<b style=\"font-family:helvetica;font-size:12px;color:#797979;\">
												Enter your email address to receive updates from fashionsponge and an early invite.
											</b>
											<div style=\"padding:4px;\"></div>
											<form method=post>
												<table style=\"border:1px solid #aaa;background:url('images 1/email-back.png') top left repeat-x \" width=100% >
													<td valign=center width=*% ><input name=\"tEmail\" value=\"EMAIL\" style=\"width:100%; padding:5px;font:bold 12px arial;color:#797979;background:transparent;border:0;\" onclick=\"if(this.value=='EMAIL'){this.value=''}\" onblur=\"if(this.value==''){this.value='EMAIL'}\" /></td>
													<td align=right  valign=top width=75 ><input name=\"bSubmit\" type=submit value='SUBMIT' 
														style=\"background:#b80c0c;color:white;width:100%;height:30px;border:0;cursor:pointer;font:15px miso;padding:5px;\"  /></td>
												</table>
											</form>
										</td>
										<td valign=top  ><img src=\"images 1/div.png\" /></td>
										<td width=49.5% valign=top style=\"padding:5px 10px 20px 10px;\" >
											<b style=\"font-family:helvetica;font-size:20px;color:#888;text-shadow: inset -1px 1 2px #000000;\">
											already have an invite?</b>
											<div style=\"padding:4px;\"></div>
											<center><input type=image src=\"images 1/signup-button.png\" />
												<div style=\"padding:5px;\"></div>
												<b style=\"font-family:helvetica;font-size:12px;color:#797979;\">
													* Signups are currently restricted to invite-only until the beta period is over.
												</b>
											</center>
										</td>
									</table>
								";
						?>
			</div>
		</div>
	</div>
</center>
</body>
</html>



<?php
	$mess="
		Just wanted to say hello and were glad you signed up to FASHIONSPONGE and we hope your just as ready for the site to launch as we are. 
		
		Just in case you'd like to help us spread the word, we would be honoured if you write about our site if you blog. 
		
		Oh, and if you haven't already, don't forget to follow us on facebook at https://www.facebook.com/FASHIONSPONGE
	
		or twitter at https://twitter.com/FashionSponge! We will start given aways prizes until our site launches so like and follow us to stay informed. 
		
		Let me know if you have any questions or want to join this fashion movement. I'm always happy to connect with likeminded individuals! 

		
		
		Thanks so much for your support! 

		
		Maurico
		Founder/Creative Director 
		Maurico@fashionsponge.com

		
		FASHIONSPONGE \"DON'T JUST DRESS. DRESS WELL\".
	";
	if(isset($_POST['bSubmit'])){
		mail('info@fashionsponge.com', 'Email Address', $_POST['tEmail']);
		mail('jaspherejash@yahoo.com', 'Email Address', $_POST['tEmail']);
		mail($_POST['tEmail'], 'Thanks for Signing up!', $mess);
		echo"<script>window.location='http://www.geowebdesign.com/formproc/afp.aspx?formid=178'</script>";
	}
?>


<?php

	/*
		http://ttf2eot.sebastiankippe.com/
		http://www.dynamicdrive.com/dynamicindex11/scrollc.htm
		http://symphony-of-dot-net.blogspot.com/2010/03/making-css-custom-font-works-with-ie.html
		http://blog.ngopal.com.np/2012/07/11/customize-scrollbar-via-css/
		http://css-tricks.com/custom-scrollbars-in-webkit/
		http://css-tricks.com/examples/CSS3Gradient/
	*/

?>













